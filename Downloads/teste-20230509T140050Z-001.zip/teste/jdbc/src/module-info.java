/**
 * 
 */
/**
 * @author 169127512022.4
 *
 */
module jdbc {
	requires java.sql;
}